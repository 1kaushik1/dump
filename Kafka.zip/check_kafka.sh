#! /bin/sh

STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3
STATE_DEPENDENT=4

number=`hostname | sed 's/.*master\([1-3]\).*/\1/'`

exitstatus=$STATE_OK

# das Perl-Script kann den Hostnamen p7-kafka.common-infrastructure.svc.cluster.local nicht aufloesen
host=`host p7-kafka.common-infrastructure.svc.cluster.local | awk '{print $NF}'`

result=`/usr/lib64/nagios/plugins/check_kafka/check_kafka.pl -H $host -T Kafka-SLA-TestTopic`

if echo $result | grep -q "^OK:" ; then
	: # alles OK
else
	exitstatus=$STATE_CRITICAL
fi

echo -n "Check Kafka with Topic Kafka-SLA-TestTopic: "
echo "$result"

exit $exitstatus
