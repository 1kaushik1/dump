#!/bin/sh

STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3
STATE_DEPENDENT=4

exitstatus=-1

JQ=/usr/local/bin/jq

dir=`dirname $0`
dir=`cd $dir && pwd`

case `hostname` in
	oshift-*)	# LAB
		TOKEN='eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJjb21tb24taW5mcmFzdHJ1Y3R1cmUiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoicm9ib3QtdG9rZW4tM3p0cXAiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoicm9ib3QiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiIxN2Y2ZDg2NC02MjRlLTExZTctYjk1ZC0wMDUwNTY4Mjc3ZWYiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6Y29tbW9uLWluZnJhc3RydWN0dXJlOnJvYm90In0.ihMXbg1T4h_O8DzFTLCM5Y5WSprizYtB9Tx890sPSyQhxqzxdZr863UnanPArkwsSfCMFNKLiY08DqrZ7Z3jSn1OU9yjaEWgMAs5c60fRAjNdjyRuLOFVdObZWMwnlVxYj20pHi0I_JtAGWin2-GPBQEi4BB22WXG79FQkTzmZSxSWU5pIejN2Plp_rSBwWCXuUvyE5x1Nhthj9WYUjTrlnHrRBKN9SHd3R9JKY1a0EoAsoLgvGLEgL9UE7PN_Nvt-2b9tYcrypK10kFQJbpgp0omC4dEWwmrRJ-QFLsGPyBJTbEU9efIyVJIjrml2oR8Drv69pmZAPL_Td4WFJ2eQ'
		;;
	app-cim*)	# INT
		TOKEN='eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJjb21tb24taW5mcmFzdHJ1Y3R1cmUiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoicm9ib3QtdG9rZW4tM3p0cXAiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoicm9ib3QiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiIxN2Y2ZDg2NC02MjRlLTExZTctYjk1ZC0wMDUwNTY4Mjc3ZWYiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6Y29tbW9uLWluZnJhc3RydWN0dXJlOnJvYm90In0.ihMXbg1T4h_O8DzFTLCM5Y5WSprizYtB9Tx890sPSyQhxqzxdZr863UnanPArkwsSfCMFNKLiY08DqrZ7Z3jSn1OU9yjaEWgMAs5c60fRAjNdjyRuLOFVdObZWMwnlVxYj20pHi0I_JtAGWin2-GPBQEi4BB22WXG79FQkTzmZSxSWU5pIejN2Plp_rSBwWCXuUvyE5x1Nhthj9WYUjTrlnHrRBKN9SHd3R9JKY1a0EoAsoLgvGLEgL9UE7PN_Nvt-2b9tYcrypK10kFQJbpgp0omC4dEWwmrRJ-QFLsGPyBJTbEU9efIyVJIjrml2oR8Drv69pmZAPL_Td4WFJ2eQ'
		;;
	*)		# PROD
		TOKEN='eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJjb21tb24taW5mcmFzdHJ1Y3R1cmUiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoicm9ib3QtdG9rZW4tNDdsMjAiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoicm9ib3QiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiJkNDM3MjZjNi02MmYzLTExZTctOTRjNC05NDE4ODIwYTVmYTAiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6Y29tbW9uLWluZnJhc3RydWN0dXJlOnJvYm90In0.TrXLP3oBILRA0PqE4lqKSUpfOcqYfkg8VmPHGz4ZtSlQR-At_jzctcoK_90aWAusCANj5V_q06GTMkHP4jEI59f_mzGtesdJjegK7JIjbZYI5URMS4Vs2lbA_w2GNNuPADyGp_fDIXR71zNbrj-ritJeDqr7-Uklf1sKGNKx4noqKwiRtsYG-n331CHsLm1IEKkKiqRjV_5S0qodJ4ZEQwYv5BoJbGz15v-8etRx2cW4m3aetlY84UW7m9l71lojPPa-7L6-I06tTNh1dUtn-HDYkh0w1r6zgoOCVwenZg2nMSMu79_Cnf3Ufwg7Lhq4kAiijqOpAUtCM82UveBBfw'
		;;
esac

broker=`curl -H "Accept: application/json" -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" -X GET https://localhost:8443/api/v1/namespaces/common-infrastructure/pods -k 2>/dev/null | $JQ --raw-output '.items[] | select(.metadata.labels.app == "p7-kafka") | .status.podIP + "|" + .metadata.labels.deploymentconfig'`

update_exitstatus()
{	if [ $1 -gt $exitstatus ]; then
		exitstatus=$1
	fi

	if [ $1 -gt 0 ]; then
		result=`echo "$result" | $JQ '.'`
	fi
}

for line in $broker ; do
	ip=`echo $line | cut -d'|' -f1`
	name=`echo $line | cut -d'|' -f2`
	# echo "$name = $ip"

	result=`curl -s $ip:8777`
	STATUS=`echo "$result" | $JQ .status -r`

	case $STATUS in
		sync)
			update_exitstatus $STATE_OK
			;;
		imok)
			update_exitstatus $STATE_WARNING
			;;
		*)
        		update_exitstatus $STATE_CRITICAL
			;;
	esac

	echo "Broker $name ($ip): $result"
done

name=p7-kafka.common-infrastructure.svc.cluster.local
result=`curl -s $name:8777/cluster`
STATUS=`echo "$result" | $JQ .status -r`

case $STATUS in
	green)
		update_exitstatus $STATE_OK
		;;
	yellow)
		update_exitstatus $STATE_WARNING
		;;
	*)
       		update_exitstatus $STATE_CRITICAL
		;;
esac
echo "Cluster $name: $result"

exit $exitstatus
