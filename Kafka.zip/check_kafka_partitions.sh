#! /bin/sh

STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3
STATE_DEPENDENT=4

exitstatus=$STATE_OK

dir=`dirname $0`
dir=`cd $dir && pwd`

master_nr=`hostname | sed 's/.*\([1-3]\)\..*/\1/'`
result=`$dir/confluent-3.0.0/bin/kafka-topics --describe --zookeeper p7-kafka-zk-${master_nr}.common-infrastructure.svc.cluster.local --under-replicated-partitions`

if [ -n "$result" ] ; then
	exitstatus=$STATE_CRITICAL
	message1="under-repliated-partitions:\n$result"
else
	message1="No under-repliated-partitions"
fi

result=`$dir/confluent-3.0.0/bin/kafka-topics --describe --zookeeper p7-kafka-zk-${master_nr}.common-infrastructure.svc.cluster.local --unavailable-partitions`

if [ -n "$result" ] ; then
	exitstatus=$STATE_CRITICAL
	message2="unavailable-partitions\n$result"
else
	message2="No unavailable-partitions"
fi

if [ $exitstatus -gt 0 ]; then
	echo -e "ERROR: Kafka\n$message1\n$message2"
else
	echo -e "OK: Kafka\n$message1\n$message2"
fi

exit $exitstatus
